Saadet 0.1.1 matching firmware source

Application commit: 2eff7f157ef73d8dd3a4f0875b9f9b66cb1c9820
Package SHA-256: fedafffd66fe35dc7fad57e11e5e6cb6adcfa21fb92760ccc3f9920c8fb30684

The application source is at this directory's root. Exact fm1-base and
felucca-bsp source copies are under dependencies/fm1-base/ and its bsp/.
SOURCE_INFO.json records the revisions and application file hashes.

Follow BUILDING.md to rebuild with ./build.sh --release 0.1.1.
The wrapper fetches the recorded revisions into build/deps/.
The JieLi compiler and SDK must be installed separately as described there;
the vendor SDK binaries and compiler are not included in this source ZIP.

MPL-covered source is supplied under MPL-2.0. Other files retain their own
licences/notices. Read LICENSE, LICENSING.md and the LICENSES directories.
Factory sound data retains its vendor attribution and separate terms.
