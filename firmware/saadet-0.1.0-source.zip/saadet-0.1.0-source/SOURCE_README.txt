Saadet 0.1.0 matching firmware source

Application commit: 991b73ba88f34f2e45fd9e16c1d1a8f169129a94
Package SHA-256: 1fb8e6f59e682d02ab46f61948a56154ff5be75e3e305fb73bf03749c4ec2957

The application source is at this directory's root. Exact fm1-base and
felucca-bsp source copies are under dependencies/fm1-base/ and its bsp/.
SOURCE_INFO.json records the revisions and application file hashes.

Follow BUILDING.md to rebuild with ./build.sh --release 0.1.0.
The wrapper fetches the recorded revisions into build/deps/.
The JieLi compiler and SDK must be installed separately as described there;
the vendor SDK binaries and compiler are not included in this source ZIP.

MPL-covered source is supplied under MPL-2.0. Other files retain their own
licences/notices. Read LICENSE, LICENSING.md and the LICENSES directories.
Factory sound data retains its vendor attribution and separate terms.
